#include "LocalPlayer.h"
#include <algorithm>
#include <cmath>
namespace {
bool Clean(Vector3& value) {
    if (!std::isfinite(value.x) || !std::isfinite(value.y)) return false;
    value.x = (std::clamp)(value.x, -89.0f, 89.0f);
    value.y = std::remainder(value.y, 360.0f); value.z = 0.0f; return true;
}
}
bool LocalPlayer::SetViewAngles(const Vector3& angle) {
    auto* ptr = Address::GetViewAnglesPtr(); auto value = angle;
    if (!ptr || !Clean(value)) return false;
    *ptr = value; return true;
}
Vector3 LocalPlayer::GetViewAngles() {
    const auto* ptr = Address::GetViewAnglesPtr(); return ptr ? *ptr : Vector3{};
}
bool LocalPlayer::SetSmoothViewAngles(Vector3 target, const int smooth) {
    auto* ptr = Address::GetViewAnglesPtr();
    if (!ptr || smooth <= 0 || !Clean(target)) return false;
    auto current = *ptr;
    if (!Clean(current)) return false;
    current.x += (target.x-current.x) / smooth;
    current.y += std::remainder(target.y-current.y, 360.0f) / smooth;
    return SetViewAngles(current);
}
