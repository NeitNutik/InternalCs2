#pragma once
#include <cmath>
#include "Vector.h"
namespace ViewDirection {
inline bool Endpoint(Vector3 origin, Vector3 angles, float length, Vector3& end) {
    constexpr float radians = 0.01745329251994329577f;
    if (!std::isfinite(origin.x) || !std::isfinite(origin.y) || !std::isfinite(origin.z) ||
        !std::isfinite(angles.x) || !std::isfinite(angles.y) || !std::isfinite(length) || length <= 0) return false;
    const float pitch = angles.x * radians, yaw = angles.y * radians;
    end = {origin.x + length * std::cos(pitch) * std::cos(yaw),
           origin.y + length * std::cos(pitch) * std::sin(yaw),
           origin.z - length * std::sin(pitch)};
    return true;
}
}
