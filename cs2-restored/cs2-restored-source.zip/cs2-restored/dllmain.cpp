// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "include.h"
#include "Cheat.h"
#include "Search.h"
#include "menu.h"
#include "imgui/font.h"
#include "Console.h"
#include "StartupState.h"

bool init = false;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

Present oPresent;
HWND window = NULL;
WNDPROC oWndProc;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView;

void InitImGui()
{
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
	ImFontConfig fontConfig{}; fontConfig.FontDataOwnedByAtlas = false;
	io.Fonts->AddFontFromMemoryTTF(&inter, sizeof inter, 16 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	chinesefont = io.Fonts->AddFontFromFileTTF("c:/windows/fonts/simhei.ttf", 15.0f, NULL, io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
	tab_text1 = io.Fonts->AddFontFromMemoryTTF(&inter, sizeof inter, 12 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	tab_text2 = io.Fonts->AddFontFromMemoryTTF(&inter, sizeof inter, 24 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	tab_text3 = io.Fonts->AddFontFromMemoryTTF(&inter, sizeof inter, 40 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	ico = io.Fonts->AddFontFromMemoryTTF(&icon, sizeof icon, 25 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	ico_2 = io.Fonts->AddFontFromMemoryTTF(&Menuicon, sizeof Menuicon, 20 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	ico_subtab = io.Fonts->AddFontFromMemoryTTF(&icon, sizeof icon, 35 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	ico_logo = io.Fonts->AddFontFromMemoryTTF(&icon, sizeof icon, 31 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	tab_textA = io.Fonts->AddFontFromMemoryTTF(&inter, sizeof inter, 19 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());
	ico_minimize = io.Fonts->AddFontFromMemoryTTF(&icon, sizeof icon, 27 * dpi_scale, &fontConfig, io.Fonts->GetGlyphRangesCyrillic());

	ImGui_ImplWin32_Init(window);
	ImGui_ImplDX11_Init(pDevice, pContext);
}

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

	if (true && ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
		return true;

	return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
}

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	if (!init)
	{
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice)))
		{
			pDevice->GetImmediateContext(&pContext);
			DXGI_SWAP_CHAIN_DESC sd;
			if (FAILED(pSwapChain->GetDesc(&sd)) || !sd.OutputWindow) {
                pContext->Release(); pContext = nullptr; pDevice->Release(); pDevice = nullptr;
                return oPresent(pSwapChain, SyncInterval, Flags);
            }
			window = sd.OutputWindow;
			oWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
			if (!oWndProc) { pContext->Release(); pDevice->Release(); pContext = nullptr; pDevice = nullptr; return oPresent(pSwapChain, SyncInterval, Flags); }
			InitImGui();
			//Console::InitConsole();
			init = true;
		}

		else
			return oPresent(pSwapChain, SyncInterval, Flags);
	}


	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

    if (Startup::GameReady) Cheat::Run();
    else {
        ImGui::Begin("Startup diagnostics");
        ImGui::TextUnformatted("Overlay loaded. Game features are unavailable.");
        ImGui::TextUnformatted("See cs2-internal-startup.log in your TEMP folder.");
        ImGui::End();
    }

	ImGui::Render();

    ID3D11Texture2D* buffer = nullptr;
    if (SUCCEEDED(pSwapChain->GetBuffer(0, IID_PPV_ARGS(&buffer)))) {
        const auto result = pDevice->CreateRenderTargetView(buffer, nullptr, &mainRenderTargetView);
        buffer->Release();
        if (SUCCEEDED(result)) {
            ID3D11RenderTargetView* previous = nullptr;
            ID3D11DepthStencilView* depth = nullptr;
            pContext->OMGetRenderTargets(1, &previous, &depth);
            pContext->OMSetRenderTargets(1, &mainRenderTargetView, nullptr);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            pContext->OMSetRenderTargets(1, &previous, depth);
            if (previous) previous->Release();
            if (depth) depth->Release();
            mainRenderTargetView->Release(); mainRenderTargetView = nullptr;
        }
    }
	return oPresent(pSwapChain, SyncInterval, Flags);
}

DWORD WINAPI MainThread(LPVOID parameter)
{
    // Pin while hooks are installed. Live unloading requires coordinated hook teardown.
    HMODULE pinned = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
        reinterpret_cast<LPCWSTR>(parameter), &pinned)) return 1;
    for (unsigned attempt = 0; attempt < Startup::ModuleRetries; ++attempt) {
        if (GetModuleHandleW(L"client.dll") && GetModuleHandleW(L"engine2.dll")) break;
        Sleep(Startup::RetryDelayMs);
    }
    PatternScan scanner;
    Startup::GameReady = scanner.InitPointers();
    for (const auto& item : scanner.GetPtrState())
        Startup::Log(item.first.data(), item.second);
    Startup::Log("GameReady", Startup::GameReady);
    for (unsigned attempt = 0; attempt < Startup::HookRetries; ++attempt) {
        auto result = kiero::init(kiero::RenderType::D3D11);
        if (result == kiero::Status::Success) {
            auto bind = kiero::bind(Startup::PresentIndex, reinterpret_cast<void**>(&oPresent), hkPresent);
            Startup::Log("Present bind status (0 = success)", bind);
            if (bind != kiero::Status::Success) kiero::shutdown();
            return bind == kiero::Status::Success ? 0 : 1;
        }
        Sleep(Startup::RetryDelayMs);
    }
    Startup::Log("D3D11 hook initialization timed out", 1);
    return 1;
}
BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        HANDLE worker = CreateThread(nullptr, 0, MainThread, module, 0, nullptr);
        if (!worker) return FALSE;
        CloseHandle(worker);
    }
    return TRUE;
}
