#pragma once
#include <Windows.h>
#include <cstdio>
#include <cstdint>
namespace Startup {
inline bool GameReady = false;
inline constexpr unsigned ModuleRetries = 120;
inline constexpr unsigned HookRetries = 120;
inline constexpr DWORD RetryDelayMs = 250;
inline constexpr unsigned short PresentIndex = 8;
inline void Log(const char* name, std::intptr_t value) {
    char path[MAX_PATH]{};
    const DWORD length = GetTempPathA(MAX_PATH, path);
    if (!length || length >= MAX_PATH || strcat_s(path, "cs2-internal-startup.log") != 0) return;
    FILE* file = nullptr;
    if (fopen_s(&file, path, "a") == 0 && file) {
        fprintf(file, "%s: 0x%llx\n", name, static_cast<unsigned long long>(value)); fclose(file);
    }
}
}
