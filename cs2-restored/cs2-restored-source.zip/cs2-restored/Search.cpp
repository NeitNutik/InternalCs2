#include "Search.h"

#include "PatternBytes.h"
#include <algorithm>
#include <cstring>

intptr_t PatternScan::GetPatternSize(const std::string& pattern) { return GetParsedPattern(pattern).size(); }
std::vector<int> PatternScan::GetParsedPattern(const std::string& pattern) { return PatternBytes::Parse(pattern); }
intptr_t PatternScan::GetPatternAddr(char* region, intptr_t size, const std::string& pattern) {
    return size > 0 ? PatternBytes::Find(region, static_cast<std::size_t>(size), GetParsedPattern(pattern)) : 0;
}
intptr_t PatternScan::GetValidMemRegion(LDR_DATA_TABLE_ENTRY* entry, const std::string& pattern) {
    if (!entry) return 0;
    auto base = reinterpret_cast<std::uintptr_t>(entry->DllBase);
    auto end = base + entry->SizeOfImage;
    std::uintptr_t found = 0;
    for (auto cursor = base; cursor < end;) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(reinterpret_cast<void*>(cursor), &mbi, sizeof mbi)) return 0;
        auto next = (std::min)(end, reinterpret_cast<std::uintptr_t>(mbi.BaseAddress) + mbi.RegionSize);
        if (next <= cursor) return 0;
        const auto protection = mbi.Protect & 0xff;
        if (mbi.State == MEM_COMMIT && !(mbi.Protect & PAGE_GUARD) &&
            (protection == PAGE_EXECUTE_READ || protection == PAGE_EXECUTE_READWRITE || protection == PAGE_EXECUTE_WRITECOPY)) {
            auto hit = GetPatternAddr(reinterpret_cast<char*>(cursor), next-cursor, pattern);
            if (hit) {
                if (found || GetPatternAddr(reinterpret_cast<char*>(hit+1), next-hit-1, pattern)) return 0;
                found = hit;
            }
        }
        cursor = next;
    }
    return found;
}

intptr_t PatternScan::ExtractPointer(intptr_t pPatternResult)
{
	if (!pPatternResult) return 0;
	intptr_t resultPointer{};

	constexpr int opcodeSize{ 3 };
	const int32_t offset{ *reinterpret_cast<int32_t*>(pPatternResult + opcodeSize) };

	constexpr int instructionSize{ 7 };
	resultPointer = pPatternResult + static_cast<intptr_t>(offset) + instructionSize;

	return resultPointer;
}

void PatternScan::SetGameEntitySystem(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern)
{
	intptr_t resultPointer{};

	// Get the address of the pattern result
	const intptr_t patternAddr{ GetValidMemRegion(pLdrEntry, pPattern) };

	if (patternAddr)
		resultPointer = ExtractPointer(patternAddr);

	Offset::GPointers::EntityList = resultPointer ? resultPointer - reinterpret_cast<intptr_t>(pLdrEntry->DllBase) : 0;
	pointersState["GameEntitySystem"] = resultPointer;
}

void PatternScan::SetGameRules(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern)
{
	intptr_t resultPointer{};

	// Get the address of the pattern result
	const intptr_t patternAddr{ GetValidMemRegion(pLdrEntry, pPattern) };

	if (patternAddr)
		resultPointer = ExtractPointer(patternAddr + 9);

	Offset::GPointers::GameRules = resultPointer ? resultPointer - reinterpret_cast<intptr_t>(pLdrEntry->DllBase) : 0;
	pointersState["GameRules"] = resultPointer;
}

void PatternScan::SetLpController(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern)
{
	intptr_t resultPointer{};

	// Get the address of the pattern result
	const intptr_t patternAddr{ GetValidMemRegion(pLdrEntry, pPattern) };

	if (patternAddr)
		resultPointer = ExtractPointer(patternAddr);

	Offset::GPointers::LP_Controller = resultPointer ? resultPointer - reinterpret_cast<intptr_t>(pLdrEntry->DllBase) : 0;
	pointersState["LP_Controller"] = resultPointer;
}

void PatternScan::SetViewMatrix(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern)
{
	intptr_t resultPointer{};

	// Get the address of the pattern result
	const intptr_t patternAddr{ GetValidMemRegion(pLdrEntry, pPattern) };

	if (patternAddr)
		resultPointer = ExtractPointer(patternAddr);

	// Storing the offset of the pointer
	Offset::GPointers::ViewMatrix = resultPointer ? resultPointer - reinterpret_cast<intptr_t>(pLdrEntry->DllBase) : 0;

	pointersState["ViewMatrix"] = resultPointer;
}

void PatternScan::SetViewAngles(LDR_DATA_TABLE_ENTRY* entry, const std::string&) {
    Offset::GPointers::ViewAngles = 0;
    const auto input = GetValidMemRegion(entry, "48 89 05 ? ? ? ? 0F 57 C0 0F 11 05");
    const auto access = GetValidMemRegion(entry, "F2 42 0F 10 84 28 ? ? ? ?  F2 0F 11 84 3A ? ? ? ?");
    if (input && access) {
        std::uint32_t member = 0;
        std::memcpy(&member, reinterpret_cast<void*>(access + 6), sizeof member);
        const auto address = ExtractPointer(input) + member;
        const auto base = reinterpret_cast<intptr_t>(entry->DllBase);
        if (address >= base && address + sizeof(Vector3) <= base + entry->SizeOfImage)
            Offset::GPointers::ViewAngles = address - base;
    }
    pointersState["ViewAngles"] = Offset::GPointers::ViewAngles;
}

void PatternScan::SetPrediction(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern)
{
	intptr_t resultPointer{};

	// Get the address of the pattern result
	const intptr_t patternAddr{ GetValidMemRegion(pLdrEntry, pPattern) };

	if (patternAddr)
		resultPointer = ExtractPointer(patternAddr);

	// Storing the offset of the pointer 
	Offset::GPointers::Prediction = resultPointer ? resultPointer - reinterpret_cast<intptr_t>(pLdrEntry->DllBase) : 0;

	pointersState["Prediction"] = resultPointer;
}

void PatternScan::SetClientMod(PVOID pDllBase)
{
	Offset::GPointers::ClientMod = reinterpret_cast<intptr_t>(pDllBase);
	pointersState["ClientDLL"] = Offset::GPointers::ClientMod;
}

void PatternScan::SetEngine2Mod(PVOID pDllBase)
{
	Offset::GPointers::Engine2Mod = reinterpret_cast<intptr_t>(pDllBase);
	pointersState["Engine2"] = Offset::GPointers::Engine2Mod;
}

bool PatternScan::InitPointers()
{
	LDR_DATA_TABLE_ENTRY* clientLdr{ GetLdrEntry(L"client.dll") };
	LDR_DATA_TABLE_ENTRY* engine2Ldr{ GetLdrEntry(L"engine2.dll") };

	pointersState.clear();
	if (!clientLdr || !engine2Ldr) return false;
	SetClientMod(clientLdr->DllBase);
	SetEngine2Mod(engine2Ldr->DllBase);

	SetGameRules(clientLdr, Pattern::GameRules);
	SetGameEntitySystem(clientLdr, Pattern::EntityList);
	SetLpController(clientLdr, Pattern::LP_Controller);
	SetViewMatrix(clientLdr, Pattern::ViewMatrix);
	SetPrediction(clientLdr, Pattern::Prediction);
	SetViewAngles(clientLdr, Pattern::CCSGoInput);

	return ArePointersInit();

}

bool PatternScan::ArePointersInit()
{
	for (const auto& pointer : pointersState)
	{
		if (!pointer.second) return false;
	}

	return true;
}

std::map<std::string_view, intptr_t> PatternScan::GetPtrState()
{
	return pointersState;
}

PEB* PatternScan::GetPEB()
{
	return (PEB*)__readgsqword(0x60);
}

LDR_DATA_TABLE_ENTRY* PatternScan::GetLdrEntry(const wchar_t* pModName)
{
	PEB* peb{ GetPEB() };

    auto* head = &peb->Ldr->InMemoryOrderModuleList;
    for (auto* node = head->Flink; node != head; node = node->Flink) {
        auto* entry = CONTAINING_RECORD(node, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        const auto& name = entry->BaseDllName;
        if (name.Buffer && name.Length / sizeof(wchar_t) == wcslen(pModName) &&
            _wcsnicmp(name.Buffer, pModName, name.Length / sizeof(wchar_t)) == 0) return entry;
    }
    return nullptr;
}
