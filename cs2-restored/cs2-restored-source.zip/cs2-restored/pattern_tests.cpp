#include "PatternBytes.h"
#include <cassert>
int main() {
 unsigned char bytes[] = {0x00,0x3f,0xaa,0xbb};
 auto b=reinterpret_cast<std::uintptr_t>(bytes);
 assert(PatternBytes::Find(bytes,4,PatternBytes::Parse("00 3F"))==b);
 assert(PatternBytes::Find(bytes,4,PatternBytes::Parse("AA BB"))==b+2);
 assert(PatternBytes::Find(bytes,4,PatternBytes::Parse("00 ? AA ??"))==b);
 assert(!PatternBytes::Find(bytes,1,PatternBytes::Parse("00 3F")));
 assert(!PatternBytes::Find(nullptr,4,PatternBytes::Parse("00")));
 assert(PatternBytes::Parse("0G").empty());
 assert(PatternBytes::Parse("0").empty());
 assert(PatternBytes::Parse("").empty());
 assert(!PatternBytes::Find(bytes,4,PatternBytes::Parse("3F BB")));
}
