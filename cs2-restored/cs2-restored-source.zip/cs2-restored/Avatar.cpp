#include "Avatar.h"
#include "imgui/imgui.h"
#include <Windows.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <shlobj.h>
#include <filesystem>
#include <fstream>
#include <vector>
#include <mutex>
#include <thread>
#include <atomic>
#include <string>
#include <stdexcept>
#include <algorithm>
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shell32.lib")
using Microsoft::WRL::ComPtr;
namespace {
constexpr DWORD MaxDownloadBytes = 8 * 1024 * 1024;
constexpr UINT MaxDimension = 4096;
constexpr UINT AvatarPixels = 256;
std::mutex guard;
std::atomic<bool> busy{false};
std::vector<unsigned char> pending;
std::string status = "Choose avatar";
ComPtr<ID3D11ShaderResourceView> texture;
ComPtr<ID3D11Device> textureDevice;
char url[2048]{};
bool started = false;
std::filesystem::path AvatarCacheFolder() {
    PWSTR value = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &value))) return {};
    std::filesystem::path path(value); CoTaskMemFree(value);
    path /= L"InternalCs2";
    std::filesystem::create_directories(path);
    return path;
}
void SetStatus(const char* value) { std::lock_guard<std::mutex> lock(guard); status = value; }
bool Download(const std::string& source, const std::filesystem::path& target) {
    if (source.rfind("https://", 0) != 0 || source.find_first_of("\"\r\n\t ") != std::string::npos) return false;
    wchar_t system[MAX_PATH]{};
    const auto count = GetSystemDirectoryW(system, MAX_PATH);
    if (!count || count >= MAX_PATH) return false;
    const auto exe = std::filesystem::path(system) / L"curl.exe";
    const int length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, source.data(), static_cast<int>(source.size()), nullptr, 0);
    if (!length) return false;
    std::wstring wide(length, L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, source.data(), static_cast<int>(source.size()), wide.data(), length);
    std::wstring command = L"\"" + exe.wstring() + L"\" --disable --fail --silent --show-error --location --max-redirs 3 --proto =https --proto-redir =https --connect-timeout 5 --max-time 20 --max-filesize " +
        std::to_wstring(MaxDownloadBytes) + L" --output \"" + target.wstring() + L"\" --url \"" + wide + L"\"";
    STARTUPINFOW startup{}; startup.cb = sizeof startup;
    PROCESS_INFORMATION process{};
    if (!CreateProcessW(exe.c_str(), command.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process)) return false;
    CloseHandle(process.hThread);
    const auto wait = WaitForSingleObject(process.hProcess, 25000);
    DWORD code = 1;
    if (wait == WAIT_OBJECT_0) GetExitCodeProcess(process.hProcess, &code);
    else { TerminateProcess(process.hProcess, 1); WaitForSingleObject(process.hProcess, INFINITE); }
    CloseHandle(process.hProcess);
    std::error_code error;
    const auto size = std::filesystem::file_size(target, error);
    return code == 0 && !error && size > 0 && size <= MaxDownloadBytes;
}
bool Decode(const std::filesystem::path& file, std::vector<unsigned char>& pixels) {
    ComPtr<IWICImagingFactory> factory;
    ComPtr<IWICBitmapDecoder> decoder;
    ComPtr<IWICBitmapFrameDecode> frame;
    ComPtr<IWICBitmapClipper> crop;
    ComPtr<IWICBitmapScaler> scaler;
    ComPtr<IWICFormatConverter> converter;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))) ||
        FAILED(factory->CreateDecoderFromFilename(file.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &decoder)) ||
        FAILED(decoder->GetFrame(0, &frame))) return false;
    UINT width=0, height=0;
    if (FAILED(frame->GetSize(&width, &height)) || !width || !height || width > MaxDimension || height > MaxDimension) return false;
    const UINT side = (std::min)(width, height);
    WICRect rect{static_cast<INT>((width-side)/2), static_cast<INT>((height-side)/2), static_cast<INT>(side), static_cast<INT>(side)};
    if (FAILED(factory->CreateBitmapClipper(&crop)) || FAILED(crop->Initialize(frame.Get(), &rect)) ||
        FAILED(factory->CreateBitmapScaler(&scaler)) || FAILED(scaler->Initialize(crop.Get(), AvatarPixels, AvatarPixels, WICBitmapInterpolationModeFant)) ||
        FAILED(factory->CreateFormatConverter(&converter)) || FAILED(converter->Initialize(scaler.Get(), GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom))) return false;
    pixels.resize(AvatarPixels*AvatarPixels*4);
    return SUCCEEDED(converter->CopyPixels(nullptr, AvatarPixels*4, static_cast<UINT>(pixels.size()), pixels.data()));
}
void Load(std::string source) {
    if (busy.exchange(true)) return;
    SetStatus("Loading avatar...");
    try { std::thread([source] {
        const auto com = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        try {
            auto folder = AvatarCacheFolder();
            if (folder.empty() || FAILED(com)) throw std::runtime_error("init");
            { std::ofstream config(folder / L"avatar.url", std::ios::trunc); config << source; }
            auto local = folder / L"avatar.png";
            auto temp = folder / (L"avatar-" + std::to_wstring(GetCurrentProcessId()) + L".download");
            const bool remote = !source.empty();
            auto input = remote ? temp : local;
            std::vector<unsigned char> pixels;
            std::error_code error;
            bool valid = !remote || Download(source, temp);
            const auto size = std::filesystem::file_size(input, error);
            valid = valid && !error && size > 0 && size <= MaxDownloadBytes && Decode(input, pixels);
            if (valid) {
                if (remote) std::filesystem::copy_file(temp, local, std::filesystem::copy_options::overwrite_existing, error);
                std::lock_guard<std::mutex> lock(guard); pending = std::move(pixels); status = "Avatar ready";
            } else SetStatus("Could not load avatar");
            if (remote) std::filesystem::remove(temp, error);
        } catch (...) { SetStatus("Could not load avatar"); }
        if (SUCCEEDED(com)) CoUninitialize();
        busy.store(false);
    }).detach(); } catch (...) { busy.store(false); SetStatus("Could not start download"); }
}
}
void Avatar::Update(ID3D11Device* device) {
    if (!device) return;
    if (!started) {
        started = true;
        try { auto folder = AvatarCacheFolder(); if (!folder.empty()) { std::ifstream file(folder / L"avatar.url"); file.getline(url, sizeof url); } } catch (...) {}
        Load(url);
    }
    std::lock_guard<std::mutex> lock(guard);
    if (textureDevice.Get() != device) { texture.Reset(); textureDevice = device; }
    if (pending.empty()) return;
    D3D11_TEXTURE2D_DESC desc{};
    desc.Width=desc.Height=AvatarPixels; desc.MipLevels=desc.ArraySize=1;
    desc.Format=DXGI_FORMAT_R8G8B8A8_UNORM; desc.SampleDesc.Count=1;
    desc.Usage=D3D11_USAGE_IMMUTABLE; desc.BindFlags=D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA data{pending.data(), AvatarPixels*4, 0};
    ComPtr<ID3D11Texture2D> image;
    ComPtr<ID3D11ShaderResourceView> view;
    if (SUCCEEDED(device->CreateTexture2D(&desc, &data, &image)) && SUCCEEDED(device->CreateShaderResourceView(image.Get(), nullptr, &view))) {
        texture = view; pending.clear();
    } else { pending.clear(); status = "Could not create avatar texture"; }
}
void Avatar::Draw(float scale) {
    if (texture) ImGui::Image(reinterpret_cast<ImTextureID>(texture.Get()), {96*scale,96*scale});
    if (ImGui::Button("Avatar settings")) ImGui::OpenPopup("Avatar settings");
    if (ImGui::BeginPopup("Avatar settings")) {
        ImGui::TextUnformatted("HTTPS image URL (empty = local avatar.png)");
        ImGui::SetNextItemWidth(380*scale);
        ImGui::InputText("##avatar-url", url, sizeof url);
        if (ImGui::Button("Load / reload") && !busy.load()) Load(url);
        { std::lock_guard<std::mutex> lock(guard); ImGui::TextUnformatted(status.c_str()); }
        ImGui::TextUnformatted("Local file: %LOCALAPPDATA%/InternalCs2/avatar.png");
        ImGui::EndPopup();
    }
}
