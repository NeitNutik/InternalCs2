#include "Address.h"

intptr_t Address::GetEntityByIndex(std::uint32_t index)
{
    using namespace Offset::EntityLayout;
    if (index > IndexMask) return 0;
    const auto list = GetEntityList();
    if (!list) return 0;
    const auto page = ReadInternalMem<intptr_t>(list, {Offset::EntityListPtr + PagePointerStride * (index >> PageBits)});
    return page ? ReadInternalMem<intptr_t>(page, {EntryStride * (index & PageMask)}) : 0;
}
intptr_t Address::GetEntityFromHandle(std::uint32_t handle)
{
    if (!handle || handle == Offset::EntityLayout::InvalidHandle) return 0;
    using namespace Offset::EntityLayout;
    if (handle == InvalidHandle - 1) return 0;
    const auto index = handle & IndexMask;
    const auto list = GetEntityList();
    const auto page = ReadInternalMem<intptr_t>(list, {Offset::EntityListPtr + PagePointerStride * (index >> PageBits)});
    if (!page) return 0;
    const auto entry = page + EntryStride * (index & PageMask);
    if (ReadInternalMem<std::uint32_t>(entry, {HandleOffset}) != handle) return 0;
    return ReadInternalMem<intptr_t>(entry, {0});
}
intptr_t Address::GetEntityBase(intptr_t index)
{
    if (index < 0 || index >= 64) return 0;
    return GetEntityByIndex(static_cast<std::uint32_t>(index + 1));
}

float* Address::GetViewMatrixPtr()
{
	return reinterpret_cast<float*>(Offset::GPointers::ClientMod + Offset::GPointers::ViewMatrix);
}

Vector3* Address::GetViewAnglesPtr()
{
	return Offset::GPointers::ClientMod && Offset::GPointers::ViewAngles ? reinterpret_cast<Vector3*>(Offset::GPointers::ClientMod + Offset::GPointers::ViewAngles) : nullptr;
}

intptr_t Address::GetPredictionBase()
{
	return Offset::GPointers::Prediction ? Offset::GPointers::ClientMod + Offset::GPointers::Prediction : 0;
}

intptr_t Address::GetLocalPlayerControl()
{
	return static_cast<intptr_t>(ReadInternalMem<uintptr_t>(Offset::GPointers::ClientMod, { Offset::GPointers::LP_Controller }));
}

intptr_t* Address::GetDeathMatchRulesPtr()
{
	const intptr_t deathMatchRulesPtr{ static_cast<intptr_t>(ReadInternalMem<uintptr_t>(Offset::GPointers::ClientMod,
		{
			Offset::GPointers::GameRules,
			Offset::CS_GameRules::GameModeRules ,
			Offset::CS_GameRules::DeathMatchPtr
		}
	)) };

	return reinterpret_cast<intptr_t*>(deathMatchRulesPtr);
}

intptr_t Address::GetEntityList()
{
	return static_cast<intptr_t>(ReadInternalMem<uintptr_t>(Offset::GPointers::ClientMod, { Offset::GPointers::EntityList }));
}