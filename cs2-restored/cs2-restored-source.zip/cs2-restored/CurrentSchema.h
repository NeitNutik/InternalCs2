#pragma once
#include <cstddef>
// Public cs2-dumper snapshot 2026-11-12; local runtime schema not dumped.
namespace VerifiedSchema {
namespace CBasePlayerController { inline constexpr std::ptrdiff_t m_iszPlayerName = 0x6FC; }
namespace CBasePlayerWeaponVData { inline constexpr std::ptrdiff_t m_iMaxClip1 = 0x4D0; }
namespace CCSPlayerController { inline constexpr std::ptrdiff_t m_bPawnIsAlive = 0x934; }
namespace CCSPlayerController { inline constexpr std::ptrdiff_t m_hPlayerPawn = 0x92C; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_WeaponType = 0x520; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_flCycleTime = 0x738; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_flInaccuracyMove = 0x788; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_flPenetration = 0x82C; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_nNumBullets = 0x730; }
namespace CCSWeaponBaseVData { inline constexpr std::ptrdiff_t m_szName = 0x720; }
namespace CGameSceneNode { inline constexpr std::ptrdiff_t m_bDormant = 0x103; }
namespace CGlowProperty { inline constexpr std::ptrdiff_t m_bGlowing = 0x51; }
namespace CGlowProperty { inline constexpr std::ptrdiff_t m_fGlowColor = 0x8; }
namespace CGlowProperty { inline constexpr std::ptrdiff_t m_glowColorOverride = 0x40; }
namespace CModelState { inline constexpr std::ptrdiff_t m_MeshGroupMask = 0x208; }
namespace CPlayer_WeaponServices { inline constexpr std::ptrdiff_t m_hActiveWeapon = 0x60; }
namespace CSkeletonInstance { inline constexpr std::ptrdiff_t m_modelState = 0x140; }
namespace C_AttributeContainer { inline constexpr std::ptrdiff_t m_Item = 0x50; }
namespace C_BaseEntity { inline constexpr std::ptrdiff_t m_iHealth = 0x34C; }
namespace C_BaseEntity { inline constexpr std::ptrdiff_t m_iTeamNum = 0x3E7; }
namespace C_BaseEntity { inline constexpr std::ptrdiff_t m_nSubclassID = 0x380; }
namespace C_BaseEntity { inline constexpr std::ptrdiff_t m_pGameSceneNode = 0x330; }
namespace C_BaseModelEntity { inline constexpr std::ptrdiff_t m_Glow = 0xDE8; }
namespace C_BaseModelEntity { inline constexpr std::ptrdiff_t m_vecViewOffset = 0xF60; }
namespace C_BasePlayerPawn { inline constexpr std::ptrdiff_t m_vOldOrigin = 0x14A4; }
namespace C_BasePlayerWeapon { inline constexpr std::ptrdiff_t m_iClip1 = 0x1928; }
namespace C_CSGameRules { inline constexpr std::ptrdiff_t m_pGameModeRules = 0xDA0; }
namespace C_CSPlayerPawn { inline constexpr std::ptrdiff_t m_ArmorValue = 0x1F00; }
namespace C_CSPlayerPawn { inline constexpr std::ptrdiff_t m_entitySpottedState = 0x1EB8; }
namespace C_CSPlayerPawnBase { inline constexpr std::ptrdiff_t m_angEyeAngles = 0x3630; }
namespace C_CSWeaponBase { inline constexpr std::ptrdiff_t m_bInReload = 0x1A7C; }
namespace C_EconItemView { inline constexpr std::ptrdiff_t m_iItemDefinitionIndex = 0x1BA; }
namespace EntitySpottedState_t { inline constexpr std::ptrdiff_t m_bSpottedByMask = 0xC; }
}
