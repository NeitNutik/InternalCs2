#include "ViewDirection.h"
#include <cassert>
#include <limits>
int main(){Vector3 p{};assert(ViewDirection::Endpoint({}, {}, 100, p));assert(std::abs(p.x-100)<.001f && std::abs(p.y)<.001f);assert(ViewDirection::Endpoint({}, {0,90,0},100,p));assert(std::abs(p.y-100)<.001f);assert(ViewDirection::Endpoint({}, {90,0,0},100,p));assert(std::abs(p.z+100)<.001f);assert(!ViewDirection::Endpoint({}, {NAN,0,0},100,p));assert(!ViewDirection::Endpoint({}, {},0,p));}
