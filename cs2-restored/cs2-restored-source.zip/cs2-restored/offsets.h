#pragma once
#include <cstdint>
#include "CS2_Dumper/offsets.hpp"
#include "CurrentSchema.h"

namespace Offset
{
	inline constexpr intptr_t EntityListPtr{ 0x10 }; // GameEntitySystem + EntityListPtr
	inline constexpr intptr_t IsMatchStarted{ 0xA0 }; // Prediction + IsMatchStarted
	inline constexpr intptr_t PlayerPawn{ VerifiedSchema::CCSPlayerController::m_hPlayerPawn };

	inline constexpr intptr_t EntityList{ cs2_dumper::offsets::client_dll::dwEntityList};
	inline constexpr intptr_t LocalPlayerControl{ cs2_dumper::offsets::client_dll::dwLocalPlayerController };
	inline constexpr intptr_t ViewMatrix{ cs2_dumper::offsets::client_dll::dwViewMatrix };

	namespace GPointers
	{
		inline intptr_t ClientMod{};
		inline intptr_t Engine2Mod{};
		inline intptr_t GameRules{};
		inline intptr_t CCSGO_Input{};
		inline intptr_t LP_Controller{};
		inline intptr_t ViewMatrix{};
		inline intptr_t ViewAngles{};
		inline intptr_t EntityList{};
		inline intptr_t Prediction{};
	}

	namespace Pawn
	{
		inline constexpr intptr_t PawnAlive = VerifiedSchema::CCSPlayerController::m_bPawnIsAlive;
		inline constexpr intptr_t BoneArray{ VerifiedSchema::CSkeletonInstance::m_modelState + 0x80 }; // GameSceneNode + BoneArray
		inline constexpr intptr_t iHealth{ VerifiedSchema::C_BaseEntity::m_iHealth };
		inline constexpr intptr_t pGameSceneNode{ VerifiedSchema::C_BaseEntity::m_pGameSceneNode };
		inline constexpr intptr_t iTeamNum{ VerifiedSchema::C_BaseEntity::m_iTeamNum };
		inline constexpr intptr_t vLastClipCameraPos{ VerifiedSchema::C_BaseModelEntity::m_vecViewOffset };
		inline constexpr intptr_t vAngEyeAngles{ VerifiedSchema::C_CSPlayerPawnBase::m_angEyeAngles };
		inline constexpr intptr_t bSpottedMask{ VerifiedSchema::C_CSPlayerPawn::m_entitySpottedState + VerifiedSchema::EntitySpottedState_t::m_bSpottedByMask }; // C_CSPlayerPawn::entitySpottedState + EntitySpottedState_t::bSpottedByMask
		inline constexpr intptr_t bDormant{ VerifiedSchema::CGameSceneNode::m_bDormant }; // GameSceneNode + bDormant
		inline constexpr intptr_t bPos{ VerifiedSchema::C_BasePlayerPawn::m_vOldOrigin }; // GameSceneNode + bDormant
		inline constexpr intptr_t IsAlive{ VerifiedSchema::CCSPlayerController::m_bPawnIsAlive };
		inline constexpr intptr_t CurrentArmor{ VerifiedSchema::C_CSPlayerPawn::m_ArmorValue };
		inline constexpr intptr_t bSpottedByMask = VerifiedSchema::C_CSPlayerPawn::m_entitySpottedState + VerifiedSchema::EntitySpottedState_t::m_bSpottedByMask;	// C_CSPlayerPawn::entitySpottedState + EntitySpottedState_t::bSpottedByMask
		inline constexpr intptr_t m_Glow = VerifiedSchema::C_BaseModelEntity::m_Glow;
		inline constexpr intptr_t m_GlowOverride = VerifiedSchema::CGlowProperty::m_glowColorOverride;
		inline constexpr intptr_t m_bGlowing = VerifiedSchema::CGlowProperty::m_bGlowing;
		inline constexpr intptr_t m_fGlowColor = VerifiedSchema::CGlowProperty::m_fGlowColor;

	};

	namespace WeaponBaseData
	{
		inline constexpr intptr_t WeaponDataPTR = VerifiedSchema::C_BaseEntity::m_nSubclassID + 0x08;
		inline constexpr intptr_t szName = VerifiedSchema::CCSWeaponBaseVData::m_szName;
		inline constexpr intptr_t Clip1 = VerifiedSchema::C_BasePlayerWeapon::m_iClip1;					// C_BasePlayerWeapon::m_iClip1
		inline constexpr intptr_t MaxClip = VerifiedSchema::CBasePlayerWeaponVData::m_iMaxClip1;					// CBasePlayerWeaponVData::m_iMaxClip1
		inline constexpr intptr_t CycleTime = VerifiedSchema::CCSWeaponBaseVData::m_flCycleTime;
		inline constexpr intptr_t Penetration = VerifiedSchema::CCSWeaponBaseVData::m_flPenetration;
		inline constexpr intptr_t WeaponType = VerifiedSchema::CCSWeaponBaseVData::m_WeaponType;
		inline constexpr intptr_t Inaccuracy = VerifiedSchema::CCSWeaponBaseVData::m_flInaccuracyMove;				// CCSWeaponBaseVData::m_flInaccuracyMove
		inline constexpr intptr_t inReload = VerifiedSchema::C_CSWeaponBase::m_bInReload;
		inline constexpr intptr_t m_nNumBullets = VerifiedSchema::CCSWeaponBaseVData::m_nNumBullets;
		inline constexpr intptr_t WeaponSize = 0x50;
		inline constexpr intptr_t ActiveWeapon = VerifiedSchema::CPlayer_WeaponServices::m_hActiveWeapon;
		inline constexpr intptr_t Item = VerifiedSchema::C_AttributeContainer::m_Item;						// C_AttributeContainer::m_Item
		inline constexpr intptr_t ItemDefinitionIndex = VerifiedSchema::C_EconItemView::m_iItemDefinitionIndex;
		inline constexpr intptr_t m_MeshGroupMask = VerifiedSchema::CModelState::m_MeshGroupMask;			// CModelState::m_MeshGroupMask
	} 

	namespace Controller
	{
		inline constexpr intptr_t cEntName{ VerifiedSchema::CBasePlayerController::m_iszPlayerName };
		inline constexpr intptr_t hPawn{ VerifiedSchema::CCSPlayerController::m_hPlayerPawn };
	};

	namespace CCSGO_Input
	{
		inline constexpr intptr_t ViewAngles{ 0xB0 }; // CCSGOInput - ViewAngles
	}

	namespace CS_GameRules
	{
		inline constexpr intptr_t GameModeRules{ VerifiedSchema::C_CSGameRules::m_pGameModeRules };
		inline constexpr intptr_t DeathMatchPtr{ 0x30 }; // GameRules + GameModeRules + DeathMatchPtr
	};
}