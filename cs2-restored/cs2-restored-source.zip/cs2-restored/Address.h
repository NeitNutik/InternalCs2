#pragma once
#include <cstddef>
#include <vector>
#include "offsets.h"
#include "Vector.h"
#include "Windows.h"

namespace Address
{
	float* GetViewMatrixPtr();
	Vector3* GetViewAnglesPtr();
	intptr_t GetPredictionBase();
	intptr_t GetLocalPlayerControl();
	intptr_t* GetDeathMatchRulesPtr();
	intptr_t GetEntityList();
	intptr_t GetEntityBase(intptr_t pIndex);
    intptr_t GetEntityByIndex(std::uint32_t index);
    intptr_t GetEntityFromHandle(std::uint32_t handle);

    template<typename T>
    T ReadInternalMem(intptr_t base, std::vector<intptr_t> offsets) {
        if (!base || offsets.empty()) return T{};
        for (std::size_t i = 0; i < offsets.size(); ++i) {
            const auto address = base + offsets[i];
            const auto size = i + 1 == offsets.size() ? sizeof(T) : sizeof(intptr_t);
            if (!base || IsBadReadPtr(reinterpret_cast<const void*>(address), size)) return T{};
            if (i + 1 == offsets.size()) return *reinterpret_cast<const T*>(address);
            base = *reinterpret_cast<const intptr_t*>(address);
        }
        return T{};
    }
}
