#pragma once
#include <cstdint>
#include <sstream>
#include <string>
#include <vector>
namespace PatternBytes {
inline std::vector<int> Parse(const std::string& text) {
    std::istringstream stream(text); std::string token; std::vector<int> out;
    while (stream >> token) {
        if (token == "?" || token == "??") { out.push_back(-1); continue; }
        if (token.size() != 2 || token.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos) return {};
        out.push_back(std::stoi(token, nullptr, 16));
    }
    return out;
}
inline std::uintptr_t Find(const void* data, std::size_t size, const std::vector<int>& pattern) {
    if (!data || pattern.empty() || pattern.size() > size) return 0;
    const auto* bytes = static_cast<const unsigned char*>(data);
    for (std::size_t i = 0; i <= size - pattern.size(); ++i) {
        std::size_t j = 0;
        for (; j < pattern.size(); ++j) if (pattern[j] >= 0 && bytes[i+j] != pattern[j]) break;
        if (j == pattern.size()) return reinterpret_cast<std::uintptr_t>(bytes+i);
    }
    return 0;
}
}
