#pragma once
#include <d3d11.h>
namespace Avatar {
void Update(ID3D11Device* device);
void Draw(float scale);
}
