#pragma once
#include "offsets.h"
#include "Vector.h"
#include "Peb.h"
#include <Windows.h>
#include <vector>
#include <map>
#include <string>
#include <string_view>

class PatternScan
{
private:
	std::map<std::string_view, intptr_t> pointersState;

	PEB* GetPEB();
	LDR_DATA_TABLE_ENTRY* GetLdrEntry(const wchar_t* pModName);

	void SetViewAngles(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	void SetPrediction(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	void SetViewMatrix(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	void SetGameRules(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	void SetLpController(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	void SetGameEntitySystem(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);

	intptr_t GetPatternSize(const std::string& pPattern);
	std::vector<int> GetParsedPattern(const std::string& pPattern);
	intptr_t GetPatternAddr(char* currRegion, intptr_t pRegionSize, const std::string& pPattern);
	intptr_t GetValidMemRegion(LDR_DATA_TABLE_ENTRY* pLdrEntry, const std::string& pPattern);
	intptr_t ExtractPointer(intptr_t pPatternResult);

public:

	void SetClientMod(PVOID pDllBase);
	void SetEngine2Mod(PVOID pDllBase);
	bool ArePointersInit();
	bool InitPointers();
	std::map<std::string_view, intptr_t> GetPtrState();
};

namespace Pattern
{
	inline const std::string EntityList{ "48 89 0D ? ? ? ? E9 ? ? ? ? CC" };
	inline const std::string ViewMatrix{ "48 8D 0D ?? ?? ?? ?? 48 C1 E0 06" };
	inline const std::string LP_Controller{ "48 8B 05 ? ? ? ? 41 89 BE" };
	inline const std::string GameRules{ "F6 C1 01 0F 85 ? ? ? ? 4C 8B 05 ? ? ? ? 4D 85" };
	inline const std::string Prediction{ "48 8D 05 ? ? ? ? C3 CC CC CC CC CC CC CC CC 40 53 56 41 54" };
	inline const std::string CCSGoInput{ "4C 89 ? ? ? ? ? 0F 11 ? ? ? ? ? 48 89 ? ? ? ? ? 4C 89" }; // Dereference 2 times
	inline const std::string BoneMatrix{ "4D 8B ? ? ? ? ? 4D 8B ? ? ? ? ? 8B 9F" };
}
