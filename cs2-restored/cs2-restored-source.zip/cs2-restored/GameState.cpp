#include "GameState.h"
#include "Entity.h"
// Readiness means a valid local pawn. Prediction is an object, not the old state integer.
bool GameState::IsMatchStarted() {
    const auto controller = Address::GetLocalPlayerControl();
    return controller && Get::PlayerPawnAddress(controller) != 0;
}
int GameState::GetMatchState() { return IsMatchStarted() ? IN_GAME : IN_LOBBY; }
bool GameState::IsDeathMatch() { return Address::GetDeathMatchRulesPtr() != nullptr; }
