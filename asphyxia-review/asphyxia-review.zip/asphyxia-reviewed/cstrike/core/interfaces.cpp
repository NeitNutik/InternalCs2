// used: [d3d] api
#include <d3d11.h>

#include "interfaces.h"

// used: findpattern, callvirtual, getvfunc...
#include "../utilities/memory.h"

// used: l_print
#include "../utilities/log.h"

// used: iswapchaindx11
#include "../sdk/interfaces/iswapchaindx11.h"
#include "../sdk/interfaces/iresourcesystem.h"

#pragma region interfaces_get

// Query the exported factory with an exact interface version. No CreateInterface opcode assumptions.
static const void* GetFactoryModule(const wchar_t* module)
{
    return MEM::GetModuleBaseHandle(module);
}

template <typename T>
T* Capture(const void* module, const char* name)
{
    if (!module) return nullptr;
    using Factory = void*(CS_CDECL*)(const char*, int*);
    auto factory = reinterpret_cast<Factory>(MEM::GetExportAddress(module, CS_XOR("CreateInterface")));
    if (!factory)
    {
        L_PRINT(LOG_ERROR) << CS_XOR("interface factory missing for: ") << name;
        return nullptr;
    }
    int status = -1;
    auto result = static_cast<T*>(factory(name, &status));
    if (result)
        L_PRINT(LOG_INFO) << CS_XOR("interface captured: ") << name;
    else
        L_PRINT(LOG_ERROR) << CS_XOR("interface unavailable: ") << name << CS_XOR("; factory status: ") << status;
    return result;
}

#pragma endregion

bool I::Setup()
{
    bool bSuccess = true;
    const auto require = [&bSuccess](const char* name, bool available)
    {
        if (!available)
        {
            L_PRINT(LOG_ERROR) << CS_XOR("I::Setup missing dependency: ") << name;
            bSuccess = false;
        }
        else
            L_PRINT(LOG_INFO) << CS_XOR("I::Setup resolved dependency: ") << name;
    };

#pragma region interface_game_exported
	const auto pTier0Handle = MEM::GetModuleBaseHandle(TIER0_DLL);
	if (pTier0Handle == nullptr)
		return false;

	MemAlloc = MEM::ReadPointer<IMemAlloc>(MEM::GetExportAddress(pTier0Handle, CS_XOR("g_pMemAlloc")));
	require("MemAlloc", MemAlloc != nullptr);

	const auto pSchemaSystemRegisterList = GetFactoryModule(SCHEMASYSTEM_DLL);
	if (pSchemaSystemRegisterList == nullptr)
		return false;

	SchemaSystem = Capture<ISchemaSystem>(pSchemaSystemRegisterList, SCHEMA_SYSTEM);
	require("SchemaSystem", SchemaSystem != nullptr);

	const auto pInputSystemRegisterList = GetFactoryModule(INPUTSYSTEM_DLL);
	if (pInputSystemRegisterList == nullptr)
		return false;

	InputSystem = Capture<IInputSystem>(pInputSystemRegisterList, INPUT_SYSTEM_VERSION);
	require("InputSystem", InputSystem != nullptr);

	const auto pEngineRegisterList = GetFactoryModule(ENGINE2_DLL);
	if (pEngineRegisterList == nullptr)
		return false;

	GameResourceService = Capture<IGameResourceService>(pEngineRegisterList, GAME_RESOURCE_SERVICE_CLIENT);
	require("GameResourceService", GameResourceService != nullptr);

	Engine = Capture<IEngineClient>(pEngineRegisterList, SOURCE2_ENGINE_TO_CLIENT);
	require("Engine", Engine != nullptr);

	NetworkClientService = Capture<INetworkClientService>(pEngineRegisterList, NETWORK_CLIENT_SERVICE);
	require("NetworkClientService", NetworkClientService != nullptr);

	const auto pTier0RegisterList = GetFactoryModule(TIER0_DLL);
	if (pTier0RegisterList == nullptr)
		return false;

	Cvar = Capture<IEngineCVar>(pTier0RegisterList, ENGINE_CVAR);
	require("Cvar", Cvar != nullptr);

	const auto pClientRegister = GetFactoryModule(CLIENT_DLL);
	if (pClientRegister == nullptr)
		return false;

	Client = Capture<ISource2Client>(pClientRegister, SOURCE2_CLIENT);
	require("Client", Client != nullptr);

	const auto pMaterialSystem2Register = GetFactoryModule(MATERIAL_SYSTEM2_DLL);
	if (pMaterialSystem2Register == nullptr)
		return false;

	MaterialSystem2 = Capture<IMaterialSystem2>(pMaterialSystem2Register, MATERIAL_SYSTEM2);
	require("MaterialSystem2", MaterialSystem2 != nullptr);

	const auto pResourceSystemRegisterList = GetFactoryModule(RESOURCESYSTEM_DLL);
	if (pResourceSystemRegisterList == nullptr)
		return false;

	ResourceSystem = Capture<IResourceSystem>(pResourceSystemRegisterList, RESOURCE_SYSTEM);
	require("ResourceSystem", ResourceSystem != nullptr);

	if (ResourceSystem != nullptr)
	{
		ResourceHandleUtils = reinterpret_cast<CResourceHandleUtils*>(ResourceSystem->QueryInterface(RESOURCE_HANDLE_UTILS));
		require("ResourceHandleUtils", ResourceHandleUtils != nullptr);
	}

#pragma endregion

	// @ida:  #STR: "r_gpu_mem_stats", "-threads", "CTSListBase: Misaligned list\n", "CTSQueue: Misaligned queue\n", "Display GPU memory usage.", "-r_max_device_threads"
	// https://media.discordapp.net/attachments/1055004763328106558/1315619131109937152/image.png?ex=6758114b&is=6756bfcb&hm=a568636a5292e2a04f94972f5781d8ad88f170a38ec2a1ce82135726dec23fac&=&format=webp&quality=lossless
	SwapChain = MEM::ReadPointer<ISwapChainDx11>(MEM::ReadPointer<ISwapChainDx11*>(MEM::ResolveRelativeAddress(MEM::FindPattern(RENDERSYSTEM_DLL, CS_XOR("66 0F 7F 0D 83 C9 43 ? 48 8B F7 66 0F 7F 05 88 C9 43 ?")), 0x4, 0x8)));
	require("SwapChain", SwapChain != nullptr);

	// grab's d3d11 interfaces for later use
	if (SwapChain != nullptr && SwapChain->pDXGISwapChain != nullptr)
	{
		if (FAILED(SwapChain->pDXGISwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&Device)))
		{
			L_PRINT(LOG_ERROR) << CS_XOR("failed to get device from swapchain");
			CS_ASSERT(false);
			return false;
		}
		else
			// we successfully got device, so we can get immediate context
			Device->GetImmediateContext(&DeviceContext);
	}
	require("D3D11 Device/DeviceContext", Device != nullptr && DeviceContext != nullptr);
	
	// #STR: CSGOInput
	Input = MEM::ReadPointer<CCSGOInput>(MEM::ResolveRelativeAddress(MEM::FindPattern(CLIENT_DLL, CS_XOR("48 89 05 ? ? ? ? 0F 57 C0 0F 11 05")), 0x3, 0x7));
	require("Input", Input != nullptr);

	// @ida: #STR: "gpGlocals->rendertime() called while IsInSimulation() is true, "gpGlocals->curtime() called while IsInSimulation() is false
	// @ida: #STR: "C_SceneEntity::SetupClientOnlyScene:  C" then go up until you see it
	GlobalVars = MEM::ReadPointer<IGlobalVars>(MEM::ResolveRelativeAddress(MEM::FindPattern(CLIENT_DLL, CS_XOR("48 89 15 ? ? ? ? 48 89 42")), 0x3, 0x7));
	require("GlobalVars", GlobalVars != nullptr);

	// @ida: #STR: "CRenderingWorldSession::OnLoopActivate" go down just a bit
	PVS = reinterpret_cast<CPVS*>(MEM::ResolveRelativeAddress(MEM::FindPattern(ENGINE2_DLL, CS_XOR("48 8D 0D ? ? ? ? 33 ? FF 50")), 0x3, 0x7)); 
	require("PVS", PVS != nullptr);

	// @ida: #STR: "Physics/TraceShape (Client)"
	// @ida: #STR: "Weapon_Knife.Stab" then go up
	GameTraceManager = MEM::ReadPointer<CGameTraceManager>(MEM::GetAbsoluteAddress(MEM::FindPattern(CLIENT_DLL, CS_XOR("48 8B 1D ? ? ? ? 24 ? 0C ? F3 0F 7F 45")), 0x3, 0x0));
	require("GameTraceManager", GameTraceManager != nullptr);

    if (!bSuccess) L_PRINT(LOG_ERROR) << CS_XOR("I::Setup failed; inspect named dependencies above");
    return bSuccess;
}

void I::CreateRenderTarget()
{
    if (!SwapChain || !SwapChain->pDXGISwapChain || !Device) return;
    DestroyRenderTarget();
	// @note: i dont use this anywhere else so lambda is fine
	static const auto GetCorrectDXGIFormat = [](DXGI_FORMAT eCurrentFormat)
	{
		switch (eCurrentFormat)
		{
		case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:
			return DXGI_FORMAT_R8G8B8A8_UNORM;
		}

		return eCurrentFormat;
	};

	DXGI_SWAP_CHAIN_DESC sd{};
    if (FAILED(SwapChain->pDXGISwapChain->GetDesc(&sd))) return;

	ID3D11Texture2D* pBackBuffer = nullptr;
	if (SUCCEEDED(SwapChain->pDXGISwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer))))
	{
		if (pBackBuffer)
		{
			D3D11_RENDER_TARGET_VIEW_DESC desc{};
			desc.Format = static_cast<DXGI_FORMAT>(GetCorrectDXGIFormat(sd.BufferDesc.Format));
			desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
			if (FAILED(Device->CreateRenderTargetView(pBackBuffer, &desc, &RenderTargetView)))
			{
				L_PRINT(LOG_WARNING) << CS_XOR("failed to create render target view with D3D11_RTV_DIMENSION_TEXTURE2D...");
				L_PRINT(LOG_INFO) << CS_XOR("retrying to create render target view with D3D11_RTV_DIMENSION_TEXTURE2DMS...");
				desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DMS;
				if (FAILED(Device->CreateRenderTargetView(pBackBuffer, &desc, &RenderTargetView)))
				{
					L_PRINT(LOG_WARNING) << CS_XOR("failed to create render target view with D3D11_RTV_DIMENSION_TEXTURE2D...");
					L_PRINT(LOG_INFO) << CS_XOR("retrying...");
					if (FAILED(Device->CreateRenderTargetView(pBackBuffer, NULL, &RenderTargetView)))
					{
						L_PRINT(LOG_ERROR) << CS_XOR("failed to create render target view");
						CS_ASSERT(false);
					}
				}
			}
			pBackBuffer->Release();
			pBackBuffer = nullptr;
		}
	}
}

void I::DestroyRenderTarget()
{
	if (RenderTargetView != nullptr)
	{
		RenderTargetView->Release();
		RenderTargetView = nullptr;
	}
}
