#pragma once

// used: schema field
#include "../../utilities/memory.h"

#include "../entity_handle.h"

#define MAX_ENTITIES_IN_LIST 512
#define MAX_ENTITY_LISTS 64 // 0x3F
#define MAX_TOTAL_ENTITIES MAX_ENTITIES_IN_LIST* MAX_ENTITY_LISTS

class C_BaseEntity;

class CGameEntitySystem
{
public:
	/// GetClientEntity
	template <typename T = C_BaseEntity>
	T* Get(int nIndex)
	{
		return reinterpret_cast<T*>(this->GetEntityByIndex(nIndex));
	}

	/// GetClientEntityFromHandle
	template <typename T = C_BaseEntity>
	T* Get(const CBaseHandle hHandle)
	{
		if (!hHandle.IsValid())
			return nullptr;

		return reinterpret_cast<T*>(this->GetEntityByIndex(hHandle.GetEntryIndex()));
	}

	int GetHighestEntityIndex()
	{
		// a2x/cs2-dumper: dwGameEntitySystem_highestEntityIndex; build 14197 reports 0x2120.
        // Read the actual displacement, not a fallback copied from another build.
        static const auto instruction = MEM::FindPattern(CLIENT_DLL, CS_XOR("FF 81 ? ? ? ? 48 85 D2"));
        if (!instruction) return -1;
        std::uint32_t offset = 0;
        std::memcpy(&offset, instruction + 2, sizeof(offset));
        const auto field = reinterpret_cast<const std::uint8_t*>(this) + offset;
        if (!MEM::IsReadable(field, sizeof(int))) return -1;
        int index = -1;
        std::memcpy(&index, field, sizeof(index));
        return (index >= -1 && index < MAX_TOTAL_ENTITIES) ? index : -1;
	}

private:
	void* GetEntityByIndex(int nIndex)
	{
		//@ida: #STR: "(missing),", "(missing)", "Ent %3d: %s class %s name %s\n" | or find "cl_showents" cvar -> look for callback
		//	do { pEntity = GetBaseEntityByIndex(g_pGameEntitySystem, nCurrentIndex); ... }
		using fnGetBaseEntity = void*(CS_THISCALL*)(void*, int);
		static auto GetBaseEntity = reinterpret_cast<fnGetBaseEntity>(MEM::FindPattern(CLIENT_DLL, CS_XOR("81 FA ? ? ? ? 77 ? 8B C2 C1 F8 ? 83 F8 ? 77 ? 48 98 48 8B 4C C1 ? 48 85 C9 74 ? 8B C2 25 ? ? ? ? 48 6B C0 ? 48 03 C8 74 ? 8B 41 ? 25 ? ? ? ? 3B C2 75 ? 48 8B 01")));
		if (nIndex < 0 || nIndex >= MAX_TOTAL_ENTITIES || !GetBaseEntity) return nullptr;
        return GetBaseEntity(this, nIndex);
	}
};
