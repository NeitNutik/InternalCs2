#include "keyvalue3.h"

bool CKeyValues3::LoadFromBuffer(const char* text)
{
    if (!text || !MEM::fnLoadKV3) return false;
    // Signature follows the decorated export already resolved by MEM::Setup:
    // bool LoadKV3(KeyValues3*, CUtlString*, const char*, const KV3ID_t&, const char*).
    // The const-reference parameter is represented as a pointer at the Win64 ABI boundary.
    const KV3ID_t format{CS_XOR("generic"), 0x41B818518343427E, 0xB5F447C23C0CDF8C};
    return MEM::fnLoadKV3(this, nullptr, text, &format, nullptr);
}
