#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <vector>

namespace pattern_scan {
inline bool matches(const std::uint8_t* data, const std::uint8_t* bytes,
                    std::size_t count, const char* mask) noexcept {
    for (std::size_t i = 0; i < count; ++i)
        if ((!mask || mask[i] != '?') && data[i] != bytes[i]) return false;
    return true;
}
inline const std::uint8_t* first(const std::uint8_t* data, std::size_t size,
                               const std::uint8_t* bytes, std::size_t count,
                               const char* mask = nullptr) noexcept {
    if (!data || !bytes || !count || count > size) return nullptr;
    for (std::size_t i = 0; i <= size - count; ++i)
        if (matches(data + i, bytes, count, mask)) return data + i;
    return nullptr;
}
inline std::vector<std::uint8_t*> all(const std::uint8_t* data, std::size_t size,
                                    const std::uint8_t* bytes, std::size_t count,
                                    const char* mask = nullptr) {
    std::vector<std::uint8_t*> out;
    if (!data || !bytes || !count || count > size) return out;
    for (std::size_t i = 0; i <= size - count; ++i)
        if (matches(data + i, bytes, count, mask)) out.push_back(const_cast<std::uint8_t*>(data + i));
    return out;
}
inline int hex(char ch) noexcept {
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    return -1;
}
// Outputs need strlen(text)+1 bytes. Supports both '?' and '??', including a final '?'.
inline std::size_t parse(const char* text, std::uint8_t* bytes, char* mask) noexcept {
    if (!text || !bytes || !mask) return 0;
    std::size_t count = 0;
    while (*text) {
        if (*text == ' ' || *text == '\t' || *text == '\r' || *text == '\n') { ++text; continue; }
        if (*text == '?') {
            ++text; if (*text == '?') ++text;
            bytes[count] = 0; mask[count++] = '?';
        } else {
            int hi = hex(*text++), lo = *text ? hex(*text++) : -1;
            if (hi < 0 || lo < 0) { bytes[0] = 0; mask[0] = 0; return 0; }
            bytes[count] = static_cast<std::uint8_t>((hi << 4) | lo); mask[count++] = 'x';
        }
    }
    bytes[count] = 0; mask[count] = 0; return count;
}
inline std::uint8_t* relative(const std::uint8_t* instruction,
                              std::ptrdiff_t displacementOffset, std::ptrdiff_t instructionEnd) noexcept {
    if (!instruction) return nullptr;
    std::int32_t displacement = 0;
    std::memcpy(&displacement, instruction + displacementOffset, sizeof(displacement));
    const auto next = reinterpret_cast<std::uintptr_t>(instruction) + instructionEnd;
    return reinterpret_cast<std::uint8_t*>(next + static_cast<std::intptr_t>(displacement));
}
}
