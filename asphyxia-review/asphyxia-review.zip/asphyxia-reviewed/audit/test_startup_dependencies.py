"""Compile the actual startup decision bodies with mocked engine symbol lookups."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
def body(path,marker):
 s=(root/path).read_text();a=s.index(marker);b=s.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
setup=body('cstrike/utilities/memory.cpp','bool MEM::Setup()')
material=body('cstrike/utilities/memory.h','[[nodiscard]] inline bool HasMaterialFunctions()')
buffer=body('cstrike/utilities/memory.h','[[nodiscard]] inline bool HasUtlBufferFunctions()')
visuals=body('cstrike/features/visuals.cpp','bool F::VISUALS::Setup()')
stub=r'''
#include <cassert>
#include <cstring>
#include <iostream>
#define CS_XOR(x) x
#define L_PRINT(x) logSink
struct Sink { template<class T> Sink& operator<<(const T&) { return *this; } } logSink;
constexpr auto DBGHELP_DLL=L"dbghelp.dll",TIER0_DLL=L"tier0.dll",MATERIAL_SYSTEM2_DLL=L"materialsystem2.dll";
namespace MEM {
bool optional=true,required=true,modules=true;
bool Setup();
void* GetModuleBaseHandle(const wchar_t*) { return modules?reinterpret_cast<void*>(1):nullptr; }
void* GetExportAddress(const void*,const char* name) {
 return (std::strcmp(name,"UnDecorateSymbolName")==0?required:optional)?reinterpret_cast<void*>(1):nullptr;
}
void* FindPattern(const wchar_t*,const char*) { return optional?reinterpret_cast<void*>(1):nullptr; }
void (*fnUnDecorateSymbolName)()=nullptr;
void (*fnLoadKV3)()=nullptr;
void (*fnCreateMaterial)()=nullptr;
void (*fnUtlBufferInit)()=nullptr;
void (*fnUtlBufferPutString)()=nullptr;
void (*fnUtlBufferEnsureCapacity)()=nullptr;
'''+material+'\n'+buffer+r'''
}
namespace F::VISUALS {
bool Setup();
namespace CHAMS { bool available=false;int cleanups=0;
bool Initialize() {return available;} void Destroy() {++cleanups;}
}}
'''+setup+'\n'+visuals+r'''
int main() {
 assert(MEM::Setup());assert(MEM::HasMaterialFunctions());assert(MEM::HasUtlBufferFunctions());
 MEM::optional=false;assert(MEM::Setup());assert(!MEM::HasMaterialFunctions());assert(!MEM::HasUtlBufferFunctions());
 MEM::required=false;assert(!MEM::Setup());MEM::required=true;
 MEM::modules=false;assert(!MEM::Setup());
 assert(F::VISUALS::Setup());assert(F::VISUALS::CHAMS::cleanups==1);
 F::VISUALS::CHAMS::available=true;assert(F::VISUALS::Setup());assert(F::VISUALS::CHAMS::cleanups==1);
 std::cout<<"12 startup dependency checks passed\n";
}
'''
with tempfile.TemporaryDirectory() as tmp:
 src=Path(tmp)/'startup.cpp';exe=Path(tmp)/'startup';src.write_text(stub)
 subprocess.run(['g++','-std=c++20','-Wall','-Wextra','-Werror',str(src),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
