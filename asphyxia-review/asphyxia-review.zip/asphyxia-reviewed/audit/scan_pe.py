#!/usr/bin/env python3
"""Read-only x64 PE signature check. No process access, injection, or ABI inference."""
import argparse,hashlib,json,re,struct
from pathlib import Path

def executable_sections(data):
 def u16(off): return struct.unpack_from('<H',data,off)[0]
 def u32(off): return struct.unpack_from('<I',data,off)[0]
 if data[:2]!=b'MZ': raise ValueError('missing DOS header')
 nt=u32(0x3c)
 if data[nt:nt+4]!=b'PE\0\0' or u16(nt+4)!=0x8664: raise ValueError('expected x64 PE')
 if u16(nt+24)!=0x20b: raise ValueError('expected PE32+')
 section_table=nt+24+u16(nt+20)
 out=[]
 for i in range(u16(nt+6)):
  off=section_table+i*40
  if off+40>len(data): raise ValueError('truncated section table')
  name=data[off:off+8].split(b'\0')[0].decode('ascii','replace')
  virtual_size,rva,raw_size,raw_offset=struct.unpack_from('<IIII',data,off+8)
  if u32(off+36)&0x20000000:
   count=min(raw_size,virtual_size)
   if raw_offset+count>len(data): raise ValueError('truncated section bytes')
   out.append((name,rva,raw_offset,data[raw_offset:raw_offset+count]))
 return out

def scan(data,patterns):
 sections=executable_sections(data);out=[]
 for p in patterns:
  tokens=p['pattern'].split()
  if any(t not in ('?','??') and not re.fullmatch(r'[0-9a-fA-F]{2}',t) for t in tokens):
   raise ValueError('invalid IDA pattern: '+p['id'])
  regex=b''.join(b'.' if '?' in t else re.escape(bytes.fromhex(t)) for t in tokens)
  matcher=re.compile(b'(?=('+regex+b'))',re.DOTALL);found=[]
  for section,rva,raw,blob in sections:
   for match in matcher.finditer(blob):
    offset=match.start();item={'section':section,'rva':hex(rva+offset),'file_offset':hex(raw+offset)}
    rel=p.get('relative')
    if rel:
     loc=offset+rel['displacement_offset']
     if loc+4<=len(blob):
      disp=struct.unpack_from('<i',blob,loc)[0]
      item['resolved_rva']=hex(rva+offset+rel['instruction_end']+disp)
    found.append(item)
  out.append({'id':p['id'],'source':f"{p['file']}:{p['line']}",'count':len(found),
              'status':'unique-unverified-semantics' if len(found)==1 else 'missing' if not found else 'ambiguous',
              'matches':found})
 return out

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--catalog',type=Path,required=True)
 ap.add_argument('--modules',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 catalog=json.loads(a.catalog.read_text());report={}
 for module in sorted({p['module'] for p in catalog}):
  files=[p for p in a.modules.rglob('*') if p.is_file() and p.name.lower()==module.lower()]
  if len(files)!=1:
   report[module]={'status':'missing-module' if not files else 'multiple-module-copies','paths':[str(p) for p in files]};continue
  blob=files[0].read_bytes()
  try: result=scan(blob,[p for p in catalog if p['module']==module])
  except (ValueError,struct.error) as e: report[module]={'status':'invalid-pe','error':str(e)};continue
  report[module]={'path':str(files[0]),'sha256':hashlib.sha256(blob).hexdigest(),'patterns':result}
 a.output.write_text(json.dumps(report,indent=2)+'\n')
 print('wrote',a.output)
