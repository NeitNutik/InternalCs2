import struct,unittest
from scan_pe import scan,executable_sections

def fixture():
 b=bytearray(0x210);b[:2]=b'MZ';struct.pack_into('<I',b,0x3c,0x80)
 b[0x80:0x84]=b'PE\0\0';struct.pack_into('<H',b,0x84,0x8664)
 struct.pack_into('<H',b,0x86,1);struct.pack_into('<H',b,0x94,0xf0)
 struct.pack_into('<H',b,0x98,0x20b);s=0x188;b[s:s+5]=b'.text'
 struct.pack_into('<IIII',b,s+8,16,0x1000,16,0x200)
 struct.pack_into('<I',b,s+36,0x60000020)
 b[0x209:0x210]=bytes.fromhex('48 8B 05 F0 FF FF FF')
 return b
class Tests(unittest.TestCase):
 def test_last_instruction_and_signed_relative(self):
  p={'id':'test','file':'fixture','line':1,'pattern':'48 8B 05 ? ? ? ?',
     'relative':{'displacement_offset':3,'instruction_end':7}}
  r=scan(fixture(),[p])[0];self.assertEqual(r['count'],1)
  self.assertEqual(r['matches'][0]['rva'],'0x1009');self.assertEqual(r['matches'][0]['resolved_rva'],'0x1000')
 def test_truncated(self):
  with self.assertRaises(ValueError): executable_sections(fixture()[:0x208])
 def test_invalid_arch(self):
  b=fixture();struct.pack_into('<H',b,0x84,0x14c)
  with self.assertRaises(ValueError): executable_sections(b)
 def test_data_section_excluded(self):
  b=fixture();struct.pack_into('<I',b,0x188+36,0x40000040)
  self.assertEqual(executable_sections(b),[])
 def test_ambiguous(self):
  p={'id':'test','file':'fixture','line':1,'pattern':'00','relative':None}
  r=scan(fixture(),[p])[0];self.assertEqual(r['count'],9);self.assertEqual(r['status'],'ambiguous')
if __name__=='__main__':unittest.main()
