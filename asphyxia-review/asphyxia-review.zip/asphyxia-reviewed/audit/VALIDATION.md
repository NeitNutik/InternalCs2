# Выполненные проверки

- Архив распакован с проверкой относительных путей; оригинал сохранён отдельно.
- Из всех cstrike/*.cpp и *.h извлечены 29 вызовов поиска IDA-паттернов в оригинале.
  Повторное использование одной строки считается отдельным call-site.
- Исправленный общий scanner/rel32 helper проверен настоящим C++ тестом:
  20 016 assertions, включая 10 000 случайных сравнений с эталонным поиском,
  последний возможный offset, перекрывающиеся совпадения, malformed hex,
  одиночный конечный '?', отрицательный disp32 и null/empty inputs.
- Тест собран g++ 14.2, C++20, -Wall -Wextra -Werror,
  -fsanitize=address,undefined. Все проверки прошли.
- Offline PE scanner: 5 unittest-тестов прошли. Проверены последний match,
  signed relative target, неоднозначность, усечённый PE, архитектура и исключение
  неисполняемой секции.
- Полный проект MSVC не собран: в среде Linux нет MSVC v143/Windows SDK.
  Попытка syntax-check через Zig/Clang остановилась на исходной зависимости
  `corecrt_math.h`; это не успешная проверка полной сборки.
- Нет локальных DLL CS2: уникальность игровых сигнатур, VTable ABI, размеры native
  protobuf, CRC, render layout и запуск в игре не проверены.

Проверки у себя (Developer PowerShell):

```powershell
cl /nologo /std:c++20 /EHsc tests\pattern_tests.cpp /Fe:pattern_tests.exe
.\pattern_tests.exe
python audit\test_scan_pe.py
msbuild asphyxia.sln /m /p:Configuration=Release /p:Platform=x64
```

Проверка сигнатур на копиях DLL:

```powershell
python audit\scan_pe.py --catalog audit\patterns-original.json --modules C:\cs2-dlls --output matches-original.json
python audit\scan_pe.py --catalog audit\patterns-patched.json --modules C:\cs2-dlls --output matches-patched.json
```
