#!/usr/bin/env python3
"""Inventory source literals. This does not validate their meaning against CS2."""
import argparse,json,re
from pathlib import Path
MODULES={'CLIENT_DLL':'client.dll','ENGINE2_DLL':'engine2.dll','SCHEMASYSTEM_DLL':'schemasystem.dll',
'INPUTSYSTEM_DLL':'inputsystem.dll','TIER0_DLL':'tier0.dll','RENDERSYSTEM_DLL':'rendersystemdx11.dll',
'MATERIAL_SYSTEM2_DLL':'materialsystem2.dll','SCENESYSTEM_DLL':'scenesystem.dll','PARTICLES_DLL':'particles.dll'}
PAT=re.compile(r'(?:MEM::)?FindPattern\(\s*(\w+)\s*,\s*(?:CS_XOR\()?"([^"]+)"')
def inventory(root):
 rows=[]
 for p in sorted((root/'cstrike').rglob('*')):
  if p.suffix not in ('.cpp','.h'): continue
  for n,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1):
   if line.strip().startswith('//'): continue
   for found in PAT.finditer(line):
    module,pattern=found.groups()
    if not re.fullmatch(r'[0-9A-Fa-f? ]+',pattern): raise ValueError(f'non-IDA literal: {p}:{n}')
    offsets=[int(x,16) for x in re.findall(r'0x[\dA-Fa-f]+',line[found.end():])]
    resolve=None
    if 'ResolveRelativeAddress(' in line and len(offsets)>=2:
     resolve={'displacement_offset':offsets[0],'instruction_end':offsets[1]}
    elif 'GetAbsoluteAddress(' in line:
     pre=offsets[0] if offsets else 0;post=offsets[1] if len(offsets)>1 else 0
     resolve={'displacement_offset':pre,'instruction_end':pre+4+post}
    rows.append({'id':f'P{len(rows)+1:02}','file':str(p.relative_to(root)),'line':n,
                 'module':MODULES.get(module,module),'pattern':pattern,'relative':resolve,'source':line.strip()})
 return rows
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
 rows=inventory(a.root);a.output.write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),'pattern calls')
