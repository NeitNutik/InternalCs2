#include "../cstrike/utilities/pattern_scan.h"
#include <array>
#include <iostream>
#include <random>
#include <stdexcept>
using namespace pattern_scan;
int count = 0;
void check(bool ok, const char* name) { ++count; if (!ok) throw std::runtime_error(name); }
int main() {
    try {
        const std::uint8_t data[]{0xAA,0xAA,0xAA,0xBB}, pattern[]{0xAA,0xAA,0xBB};
        check(first(data,4,pattern,3)==data+1,"overlap after partial prefix");
        check(first(data,4,data,4)==data,"equal-sized region");
        check(first(data,4,data+3,1)==data+3,"last byte");
        check(!first(data,1,pattern,3),"oversized pattern");
        check(!first(data,4,pattern,0),"empty pattern");
        check(!first(nullptr,4,pattern,3),"null region");
        check(all(data,3,data,2).size()==2,"overlapping occurrences");
        check(all(data,4,pattern,3).size()==1,"all occurrences with partial prefix");
        std::uint8_t bytes[64]{}; char mask[64]{};
        check(parse("48 8B ?",bytes,mask)==3 && mask[2]=='?',"trailing single wildcard");
        check(parse("48??8B",bytes,mask)==3 && bytes[2]==0x8B,"compact wildcard");
        check(parse("?",bytes,mask)==1,"single wildcard");
        check(parse("A",bytes,mask)==0,"odd hex token rejected");
        check(parse("GG",bytes,mask)==0,"invalid hex rejected");
        std::array<std::uint8_t,32> region{}; std::int32_t disp=-12;
        std::memcpy(region.data()+19,&disp,4);
        check(relative(region.data()+16,3,7)==region.data()+11,"negative disp32");
        disp=4; std::memcpy(region.data()+3,&disp,4);
        check(relative(region.data(),3,7)==region.data()+11,"positive disp32");
        check(!relative(nullptr,3,7),"null relative address");
        std::mt19937 rng(31415926);
        for (int test=0;test<10000;++test) {
            std::array<std::uint8_t,32> hay{},needle{}; std::array<char,32> wild{};
            auto n=rng()%33,m=rng()%33;
            for(auto& b:hay) b=rng()%4;
            for(auto& b:needle) b=rng()%4;
            for(auto& b:wild) b=rng()%3?'x':'?';
            std::vector<std::uint8_t*> reference;
            if(m&&m<=n) for(unsigned i=0;i<=n-m;++i) {
                bool equal=true;
                for(unsigned j=0;j<m;++j) if(wild[j]!='?'&&hay[i+j]!=needle[j]) equal=false;
                if(equal) reference.push_back(hay.data()+i);
            }
            check(all(hay.data(),n,needle.data(),m,wild.data())==reference,"random differential search");
            check(first(hay.data(),n,needle.data(),m,wild.data())==(reference.empty()?nullptr:reference.front()),"random first search");
        }
        std::cout<<count<<" checks passed\n";
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 1; }
}
